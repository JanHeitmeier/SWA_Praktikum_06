package de.hsos.swa.gateway;

public class KundenRepository {
}
