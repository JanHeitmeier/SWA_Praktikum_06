package de.hsos;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class ExampleResourceIT extends ExampleResourceTest {
    // Execute the same tests but in packaged mode.
}
